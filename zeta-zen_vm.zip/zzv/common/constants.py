HEALTH_REPORT = "health_report"
KERNEL = "zeta_zen_vm"
QUEUE_MANAGER = "queue_manager"
MSG_MANAGER = "msg_manager"

SNAPSHOT_LIST = "SnapshotList"
