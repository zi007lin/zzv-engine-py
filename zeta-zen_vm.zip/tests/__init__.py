class ScreenshotAnalyzerAWS:
    pass
